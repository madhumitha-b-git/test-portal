import bcrypt
from datetime import datetime, timezone

from boto3.dynamodb.conditions import Attr

from database.dynamodb import (
    get_users_table,
    get_answers_table,
    get_questions_table,
)

from services.sns_service import publish_test_submitted_event


def hash_password(password: str) -> str:
    """Hashes a plain text password with bcrypt."""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode("utf-8"), salt).decode("utf-8")


def verify_password(password: str, hashed_password: str) -> bool:
    """Verifies a plain text password against a bcrypt hash."""
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed_password.encode("utf-8"))
    except Exception:
        return False


def register_candidate(
    name: str,
    mailId: str,
    mobile: str,
    college: str,
    password: str,
):
    """
    Stores candidate details in Users table with hashed password.
    """

    table = get_users_table()

    existing_user = table.get_item(Key={"mailId": mailId})
    if "Item" in existing_user:
        return {
            "success": False,
            "message": "Email already exists. Please log in with your credentials."
        }

    hashed_pw = hash_password(password)

    table.put_item(
        Item={
            "mailId": mailId,
            "name": name,
            "mobile": mobile,
            "college": college,
            "password": hashed_pw,
            "registeredAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
    )

    return {
        "success": True,
        "message": "Registered successfully",
        "user": {
            "name": name,
            "mailId": mailId,
            "mobile": mobile,
            "college": college,
        }
    }


def login_candidate(
    mailId: str,
    password: str,
):
    """
    Validates candidate credentials and retrieves registration details.
    """

    table = get_users_table()

    existing_user = table.get_item(Key={"mailId": mailId})
    if "Item" not in existing_user:
        return {
            "success": False,
            "message": "No candidate account found with this email. Please register first."
        }

    user = existing_user["Item"]
    stored_hash = user.get("password")

    # If user has a password stored, verify it
    if stored_hash:
        if not verify_password(password, stored_hash):
            return {
                "success": False,
                "message": "Incorrect password. Please try again."
            }

    # Check if test has already been submitted in the answers table
    answers_table = get_answers_table()
    answer_record = answers_table.get_item(Key={"mailId": mailId})
    is_submitted = "Item" in answer_record

    return {
        "success": True,
        "message": "Login successful",
        "user": {
            "name": user.get("name", ""),
            "mailId": user.get("mailId", ""),
            "mobile": user.get("mobile", ""),
            "college": user.get("college", ""),
        },
        "isSubmitted": is_submitted
    }


def submit_answers(
    mailId: str,
    testId: str,
    submittedAt: str,
    sections: list,
):
    """
    Stores candidate answers in DynamoDB
    and publishes the same response format to SNS.
    """

    table = get_answers_table()

    # Convert Pydantic models into plain dictionaries
    sections_data = [
        section.model_dump(exclude_none=True)
        for section in sections
    ]

    submit_time = datetime.now(
        timezone.utc
    ).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Save submission to DynamoDB
    table.put_item(
        Item={
            "mailId": mailId,
            "testId": testId,
            "sections": sections_data,
            "submittedAt": submittedAt,
        }
    )

    # Publish the exact structure to SNS
    sns_result = publish_test_submitted_event(
        test_id=testId,
        mail_id=mailId,
        sections=sections_data,
        submitted_at=submittedAt,
    )

    return {
        "success": True,
        "message": "Answers submitted successfully",
        "sns_message_id": sns_result["message_id"],
    }


def get_answers_by_test_id(
    test_id: str,
):
    """
    Fetches answers for a specific testId
    from Answers table.
    """

    table = get_answers_table()

    response = table.scan(
        FilterExpression=Attr("testId").eq(test_id)
    )

    return response.get("Items", [])


def get_candidate_answers(
    mail_id: str,
):
    """
    Fetches candidate details from Users table
    and answers from Answers table.
    """

    users_table = get_users_table()
    answers_table = get_answers_table()

    user_response = users_table.get_item(
        Key={
            "mailId": mail_id,
        }
    )

    answer_response = answers_table.get_item(
        Key={
            "mailId": mail_id,
        }
    )

    return {
        "candidate": user_response.get(
            "Item",
            {}
        ),
        "testData": answer_response.get(
            "Item",
            {}
        ),
    }


def get_candidate(
    mail_id: str,
):
    """
    Fetches candidate details from Users table.
    """

    users_table = get_users_table()

    response = users_table.get_item(
        Key={
            "mailId": mail_id,
        }
    )

    return response.get(
        "Item",
        {}
    )